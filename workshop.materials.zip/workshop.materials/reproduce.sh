bwa index toy.ref.fasta

